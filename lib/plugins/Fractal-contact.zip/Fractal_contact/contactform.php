<?php
/*
Plugin Name: Fractal Contact Form
Plugin URI: http://example.com
Description: Simple non-bloated WordPress Contact Form. Shortcode - [fractal_contact_form]
Version: 1.0
Author: Serhii Prokhorenko
Author URI: http://example.com
*/

function html_form_code() {
	echo '<form class="contact-form" action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
		echo '<div class="col-xs-12 col-sm-4 input-group-lg">';
			echo '<input type="text" class="form-control" name="cf-name" pattern="[a-zA-Z0-9 ]+" value="' . ( isset( $_POST["cf-name"] ) ? esc_attr( $_POST["cf-name"] ) : '' ) . '" placeholder="Your Name"/>';
		echo '</div>';
		echo '<div class="col-xs-12 col-sm-4 input-group-lg">';
			echo '<input type="email" class="form-control" name="cf-email" value="' . ( isset( $_POST["cf-email"] ) ? esc_attr( $_POST["cf-email"] ) : '' ) . '" placeholder="Email" />';
		echo '</div>';
		echo '<div class="col-xs-12 col-sm-4 input-group-lg">';
			echo '<input type="tel" class="form-control" name="cf-phone" pattern="[0-9 ]+" value="' . ( isset( $_POST["cf-phone"] ) ? esc_attr( $_POST["cf-phone"] ) : '' ) . '" placeholder="Phone" />';
		echo '</div>';
		echo '<div class="col-xs-12 col-sm-12 comments">';
			echo '<textarea type="text" class="main_input_height form-control" placeholder="Your Message" name="cf-message">' . ( isset( $_POST["cf-message"] ) ? esc_attr( $_POST["cf-message"] ) : '' ) . '</textarea>';
		echo '</div>';
		echo '<div class="pin col-xs-12  col-sm-12">';
			echo '<p class="text-center"><input type="submit" name="cf-submitted" value="Send"/></p>';
		echo '</div>';
	echo '</form>';
}
 
function deliver_mail() {
 
    // if the submit button is clicked, send the email
    if ( isset( $_POST['cf-submitted'] ) ) {
 
        // sanitize form values
        $name    = sanitize_text_field( $_POST["cf-name"] );
        $email   = sanitize_email( $_POST["cf-email"] );
        $phone	 = sanitize_text_field( $_POST["cf-phone"] );
        $subject = 'Fractal Soft response';
        $message = esc_textarea( $_POST["cf-message"] );
 
        // get the blog administrator's email address
        $to = get_option( 'admin_email' );
 
        $headers = "From: $name <$email>, $phone" . "\r\n";
 
        // If email has been process for sending, display a success message
        if ( wp_mail( $to, $subject, $message, $headers ) ) {
            
            echo "<script type='text/javascript'>alert('Thanks for contacting us, expect a response soon.')</script>";
            
        } else {
            echo "<script type='text/javascript'>alert('An unexpected error occurred.')</script>";
        }
    }
}

add_action( 'plugins_loaded', 'deliver_mail' );
 
function cf_shortcode() {
    ob_start();
    deliver_mail();
    html_form_code();
 
    return ob_get_clean();
}
 
add_shortcode( 'fractal_contact_form', 'cf_shortcode' );
 
?>